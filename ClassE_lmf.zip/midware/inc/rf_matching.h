#ifndef __RF_MATCHING_H
#define __RF_MATCHING_H

#include "main.h"
#include "bsp_sys_ctrl.h"
/* 配置参数 */
#define RELAY_COMB_MAX      16      // 16种组合 (0x00 - 0x0F)
#define ADC_SAMPLE_AVG      20      // ADC采样平均次数
#define RELAY_STABLE_MS     200     // 继电器机械稳定延时
#define RF_SETTLE_MS        50      // 射频开启后稳定延时


/* 接口 */
HAL_StatusTypeDef RF_Matching_Optimize(void);

#endif /* __RF_MATCHING_H */