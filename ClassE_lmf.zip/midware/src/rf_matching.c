#include "rf_matching.h"
#include "adc.h"
#include "tim.h"

extern void Relay_Set_Combination(uint8_t combination);
extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim3; // 假设射频PWM使用htim3

/**
 * @brief  私有函数：获取指定ADC通道的平均值 (阻感/驻波比检测)
 * @param  Channel: ADC_CHANNEL_0 或 ADC_CHANNEL_1
 */
static uint32_t Get_ADC_Average(uint32_t Channel) {
		
		//配置ADC通道
    uint32_t sum = 0;
		ADC_ChannelConfTypeDef sConfig = {0};
    sConfig.Channel = Channel;
    sConfig.Rank = 1;
    sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5; 
    if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) return 0;
		//开始遍历
    for (int i = 0; i < ADC_SAMPLE_AVG; i++) {
        HAL_ADC_Start(&hadc1);
        if (HAL_ADC_PollForConversion(&hadc1, 10) == HAL_OK) {
            sum += HAL_ADC_GetValue(&hadc1);
        }
        HAL_ADC_Stop(&hadc1);
    }
    return sum / ADC_SAMPLE_AVG;
}

/**
 * @brief  自动遍历继电器组合，寻找反射功率最小的最佳点
 * @note   包含射频保护逻辑：切换前关闭RF，测量时开启小功率
 */
HAL_StatusTypeDef RF_Matching_Optimize(void) {
    uint8_t best_comb = 0;
    float min_reflect_ratio = 9999.0f;
    
    // 1. 初始化时先关闭射频输出
		Sys_Stop();
	
    for (uint8_t i = 0; i < RELAY_COMB_MAX; i++) {
        // --- 步骤 A: 冷切换继电器 ---
        Relay_Set_Combination(i);
        HAL_Delay(RELAY_STABLE_MS); // 等待触点吸合稳定

        // --- 步骤 B: 开启低功率探测脉冲 ---
				//todo:添加低功率设置操作
				Sys_Start();
        
        HAL_Delay(RF_SETTLE_MS); // 等待射频建立稳态

        // --- 步骤 C: 采集前向和反向功率 ---
        uint32_t fwd_raw = Get_ADC_Average(ADC_CHANNEL_0); // 前向功率通道
        uint32_t ref_raw = Get_ADC_Average(ADC_CHANNEL_1); // 反射功率通道

        // --- 步骤 D: 计算并比较 ---
        float current_ratio;
        if (fwd_raw < 100) { // 如果前向功率太低，说明系统异常或未开启
            current_ratio = 9998.0f; 
        } else {
            current_ratio = (float)ref_raw / (float)fwd_raw;
        }

        if (current_ratio < min_reflect_ratio) {
            min_reflect_ratio = current_ratio;
            best_comb = i;
        }
        // --- 步骤 E: 关闭射频，准备下一次切换 ---
        Sys_Stop();
    }

    // 2. 最终切换到最优组合
    Relay_Set_Combination(best_comb);
    HAL_Delay(RELAY_STABLE_MS);
    
    return HAL_OK;
}