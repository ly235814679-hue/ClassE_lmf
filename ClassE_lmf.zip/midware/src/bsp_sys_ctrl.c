#include "bsp_sys_ctrl.h"

/**
  * @brief  系统控制IO初始化
  */
void Sys_Ctrl_Init(void)
{
	PWR_OFF();	
	SIG_OFF();
}

/**
  * @brief  开启系统
  * @note   时序：电源开启 -> 信号开启
  */
void Sys_Start(void)
{
    /* 1. 开启电源 */
    PWR_ON();

    /* 2. 开启信号 */
    SIG_ON();
}

/**
  * @brief  关闭系统
  * @note   时序：电源关闭 -> 信号关闭 (根据用户指定顺序)
  */
void Sys_Stop(void)
{
    /* 1. 关闭电源 */
    PWR_OFF();
	
		/* 2. 等待一会... */
		DWT_Delay_us(50);
	
		/* 3. 关闭信号源 */
    SIG_OFF();
}