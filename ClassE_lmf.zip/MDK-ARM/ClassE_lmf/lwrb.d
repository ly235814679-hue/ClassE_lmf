classe_lmf/lwrb.o: ..\lwrb\lwrb\lwrb.c ..\lwrb\include\lwrb\lwrb.h
