classe_lmf/multi_button.o: ..\multibutton\multi_button.c \
  ..\multibutton\multi_button.h
