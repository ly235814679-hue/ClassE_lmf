classe_lmf/lwrb_ex.o: ..\lwrb\lwrb\lwrb_ex.c ..\lwrb\include\lwrb\lwrb.h
