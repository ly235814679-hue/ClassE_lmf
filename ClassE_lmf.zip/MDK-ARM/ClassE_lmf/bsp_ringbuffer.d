classe_lmf/bsp_ringbuffer.o: ..\midware\src\bsp_ringbuffer.c \
  ..\midware\inc\bsp_ringbuffer.h ..\lwrb\include\lwrb\lwrb.h
