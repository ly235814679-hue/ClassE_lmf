classe_lmf/lwevt.o: ..\lwevt\src\lwevt\lwevt.c \
  ..\lwevt\src\include\lwevt\lwevt.h \
  ..\lwevt\src\include\lwevt\lwevt_opt.h \
  ..\lwevt\src\include\lwevt\lwevt_opts.h \
  ..\lwevt\src\include\lwevt\lwevt_type.h \
  ..\lwevt\src\include\lwevt\lwevt_types.h
