classe_lmf/multitimer.o: ..\multitimer\MultiTimer.c \
  ..\multitimer\MultiTimer.h
