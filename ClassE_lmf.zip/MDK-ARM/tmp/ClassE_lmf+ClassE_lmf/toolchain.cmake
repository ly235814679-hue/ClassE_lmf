# toolchain.cmake

set(REGISTERED_TOOLCHAIN_ROOT "e:/Program/Cadence16.6/.vcpkg/artifacts/2139c4c6/compilers.arm.armclang/6.24.0/bin/")
set(REGISTERED_TOOLCHAIN_VERSION "6.24.0")
include("${CMSIS_COMPILER_ROOT}/AC6.6.16.2.cmake")

